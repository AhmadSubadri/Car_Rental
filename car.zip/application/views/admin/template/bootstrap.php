<?php require('header.php'); ?>
    <?php echo $content; ?>
<?php require('footer.php'); ?>