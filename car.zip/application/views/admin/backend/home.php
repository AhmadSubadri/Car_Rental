<!-- Begin Page Content -->
<div class="container-fluid">
	<!-- Page Heading -->
	<div class="d-sm-flex align-items-center justify-content-between mb-4">
		<h1 class="h3 align-items-center">Selamat datang admin-adminku</h1>
	</div>
	<!-- Content Row -->
	<div class="row">
		<!-- Earnings (Monthly) Card Example -->
		<h1 class="display-4"></h1>
		<p>Ini adalah dashboard admin dari Asikrentcars. silahkan manfaatkan dengan baik tools yang ada</p>
	</div>
</div>
<!-- /.container-fluid -->
</div>
<!-- End of Main Content -->