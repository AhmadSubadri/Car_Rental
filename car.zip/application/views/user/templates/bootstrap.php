<?php require('header.php'); ?>
<?php echo $content; ?>
<?php require('footer.php'); ?>

<div style="position:fixed;left:20px;bottom:20px;">
        <a href="https://api.whatsapp.com/send?phone=+6281381945880&text=Hallo mas mau tanya untuk rental mobil-nya masih ada yg ready?">
                <button style="background:#32C03C;vertical-align:center;height:50px;border-radius:5px">
                        <i class="fa fa-whatsapp"> Hubungi kami</i>
                </button>
        </a>
</div>